package worldline.ssm.rd.ux.wlmastodon.interfaces;

import java.util.List;

import worldline.ssm.rd.ux.wlmastodon.pojo.Tweet;

public interface TweetChangeListener {
    public void onTweetRetrieved(List<Tweet> tweets);
}
