package worldline.ssm.rd.ux.wlmastodon;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import worldline.ssm.rd.ux.wlmastodon.utils.Constants;
import worldline.ssm.rd.ux.wlmastodon.utils.PreferenceUtils;

public class WLMastodonLoginActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mLoginEditText;
    private EditText mPasswordEditText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        findViewById(R.id.loginButton).setOnClickListener(this);

        mLoginEditText = findViewById(R.id.loginEditTextText);
        mPasswordEditText = findViewById(R.id.editTextTextPassword);

        String mStoredLogin = PreferenceUtils.getLogin();

        if (!TextUtils.isEmpty(mStoredLogin)) {
            startActivity(getIntent(mStoredLogin));
        }
    }

    @Override
    public void onClick(View view) {
        if (TextUtils.isEmpty(mLoginEditText.getText())) {
            Toast.makeText(this, R.string.error_no_login, Toast.LENGTH_LONG).show();
        }

        if (TextUtils.isEmpty(mPasswordEditText.getText())) {
            Toast.makeText(this, R.string.error_no_password, Toast.LENGTH_LONG).show();
        }

        startActivity(getIntent(mLoginEditText.getText().toString()));


    }

    Intent getIntent(String login) {
        Intent intent = new Intent(this, WLMastodonActivity.class);
        final Bundle extras = new Bundle();
        extras.putString(Constants.Login.EXTRA_LOGIN, login);
        intent.putExtras(extras);

        return intent;
    }
}
