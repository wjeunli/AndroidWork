package worldline.ssm.rd.ux.wlmastodon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import worldline.ssm.rd.ux.wlmastodon.fragments.TweetsFragment;
import worldline.ssm.rd.ux.wlmastodon.pojo.Tweet;
import worldline.ssm.rd.ux.wlmastodon.utils.Constants;
import worldline.ssm.rd.ux.wlmastodon.utils.PreferenceUtils;
import worldline.ssm.rd.ux.wlmastodon.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class WLMastodonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Intent intent = getIntent();

        if (null != intent) {
            final Bundle extras = intent.getExtras();
            if (null != extras) {
                final String login = extras.getString(Constants.Login.EXTRA_LOGIN);
                getSupportActionBar().setSubtitle(login);
                getSupportFragmentManager().beginTransaction().add(R.id.container, new TweetsFragment()).commit();
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.wlmastodon, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.actionLogout) {
            PreferenceUtils.setLogin(null);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
