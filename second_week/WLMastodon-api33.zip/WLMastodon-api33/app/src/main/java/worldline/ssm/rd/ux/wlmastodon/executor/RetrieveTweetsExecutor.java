package worldline.ssm.rd.ux.wlmastodon.executor;

import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import worldline.ssm.rd.ux.wlmastodon.helpers.MastodonHelper;
import worldline.ssm.rd.ux.wlmastodon.interfaces.TweetChangeListener;
import worldline.ssm.rd.ux.wlmastodon.pojo.Tweet;

public class RetrieveTweetsExecutor {

    private ExecutorService mExecutorService;
    private Handler mHandler;
    private TweetChangeListener mListener;

    public RetrieveTweetsExecutor(TweetChangeListener listener) {
        mExecutorService = Executors.newSingleThreadExecutor();
        mHandler = new Handler(Looper.getMainLooper());
        mListener = listener;
    }

    public void getTweets(String user) {
        mExecutorService.execute(() -> {
            List<Tweet> tweets = MastodonHelper.getTweetsOfUser(user);
            if (null != tweets) {
                mHandler.post(() -> {
                    mListener.onTweetRetrieved(tweets);
                });
            }
        });
    }
}
